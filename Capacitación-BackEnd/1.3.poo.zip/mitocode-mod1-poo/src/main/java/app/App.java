package app;

import model.Product;

public class App {

    public static void main(String[] args) {
        //System.out.println("Hola desde Java 21");
        byte x1 = 127;
        short x2 = 32_767;
        int x3 = 327677;
        float x4 = 32767.0f;
        double x5 = 32767.05d;

        char x = 'a';
        boolean y = true;

        String xyz = "mitocode"; //Clase Wrapper
        Integer abc = 22222;

        int age1 = 34;
        Integer age2 = null;

        //Java Promotions
        byte a = 5;
        byte b = 10;
        byte c = (byte) (a + b);

        int d = 5;
        double e = 10;
        double f = d + e;

        //System.out.println(c);

        Product p = new Product();
        p.setName("TV");
        p.setPrice(99);
        System.out.println(p.getName());

    }
}
