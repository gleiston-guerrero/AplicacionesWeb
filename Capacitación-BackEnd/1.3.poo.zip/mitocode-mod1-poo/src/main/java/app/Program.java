package app;

import lombok.Cleanup;
import model.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

public class Program {

    public static void main(String[] args) {
        @Cleanup Scanner sc = new Scanner(System.in);
        System.out.println("Enter client data: ");
        System.out.println("Name: ");
        String name = sc.nextLine();
        System.out.println("Email: ");
        String email = sc.nextLine();
        System.out.println("Birth date: (YYYY-MM-DD): ");
        String birthDateString = sc.nextLine();
        LocalDate birthDate = LocalDate.parse(birthDateString);

        Client client = new Client(name, email, birthDate);

        System.out.println("Enter order data: ");
        System.out.println("Status: ");
        OrderStatus status = OrderStatus.valueOf(sc.nextLine());

        Order order = new Order(LocalDateTime.now(), status, client, new ArrayList<>());

        System.out.println("How many items do you want to add? ");
        int numberOfItems = sc.nextInt();

        for(int i = 1; i <= numberOfItems; i++) {
            System.out.println("Enter #" + i + " item data: ");
            System.out.println("Product Name: ");
            String productName = sc.next();
            System.out.println("Product Price: ");
            double productPrice = sc.nextDouble();
            System.out.println("Product Quantity: ");
            int productQuantity = sc.nextInt();

            Product product = new Product(productName, productPrice);
            OrderItem orderItem = new OrderItem(productQuantity, productPrice, product);

            order.addItem(orderItem);
        }

        System.out.println("ORDER SUMMARY: ");
        System.out.println(order);

        //sc.close();
    }
}
