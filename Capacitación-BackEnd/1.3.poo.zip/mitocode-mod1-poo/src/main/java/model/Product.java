package model;

import lombok.*;

import java.util.Objects;

//POJO

/*@Getter
@Setter
@ToString
@EqualsAndHashCode*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {

    private String name;
    private double price;

}
