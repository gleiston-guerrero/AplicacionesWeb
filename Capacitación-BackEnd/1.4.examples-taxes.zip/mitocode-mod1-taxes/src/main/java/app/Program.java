package app;

import lombok.Cleanup;
import model.Company;
import model.Individual;
import model.TaxPayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Program {

    public static void main(String[] args) {
        @Cleanup Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of tax payer: ");
        int numberOfTaxPayers = sc.nextInt();

        List<TaxPayer> list = new ArrayList<>();

        for (int i = 1; i <= numberOfTaxPayers; i++) {
            System.out.println("Tax payer #" + i + ": ");
            System.out.println("Individual or Company (i/c)?");

            char type = sc.next().charAt(0);
            System.out.println("Name: ");
            String name = sc.next();
            System.out.println("Anual Income: ");
            double anualIncome = sc.nextDouble();

            if(type == 'i'){
                System.out.println("Health Expenditures: ");
                double healthExpenditures = sc.nextDouble();
                Individual ind = new Individual(name, anualIncome, healthExpenditures);
                list.add(ind);
            }else{
                System.out.println("Number of Employees");
                int numberOfEmployees = sc.nextInt();
                Company comp = new Company(name, anualIncome, numberOfEmployees);
                list.add(comp);
            }
        }

        System.out.println("==========================================");
        System.out.println("PAID TAXES: ");

        double sum = 0;
        for (TaxPayer tx : list) {
            System.out.println(tx.getName() + " : $" + tx.calculateTaxes());
            sum += tx.calculateTaxes();
        }

        System.out.println("Total taxes: " + sum);
    }
}
