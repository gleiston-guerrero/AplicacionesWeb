package model;

import lombok.AllArgsConstructor;

public class Individual extends TaxPayer{
    private Double healthExpenditures;

    public Individual(String name, Double anualIncome, Double healthExpenditures) {
        super(name, anualIncome);
        this.healthExpenditures = healthExpenditures;
    }

    @Override
    public double calculateTaxes() {
        double basicTax = 0;

        if(healthExpenditures < 20_000){
            basicTax = getAnualIncome() * 0.15;
        }else{
            basicTax = getAnualIncome() * 0.25;
        }

        basicTax -= healthExpenditures * 0.5;

        if(basicTax < 0){
            basicTax = 0;
        }

        return basicTax;
    }
}
