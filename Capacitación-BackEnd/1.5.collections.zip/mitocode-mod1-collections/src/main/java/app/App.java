package app;

import model.Employee;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class App {

    public static void main(String[] args) {
        List<Employee> list = new ArrayList<>();

        Employee e1 = new Employee(1, "Juan", 1000);
        Employee e2 = new Employee(2, "Pedro", 1000);

        list.add(e1);
        list.add(e2);

        List<Employee> list2 = Arrays.asList(e1, e2);
        List<Employee> list3 = new ArrayList<>(500);

        //| e1 | e2 | e3 | e4 | e5 | e6 | ..... e500| +501

        List<Employee> list4 = new ArrayList<>();
        list4.add(new Employee(1, "Juan", 1000.00));
        list4.add(new Employee(2, "Pedro", 2000.00));
        list4.add(new Employee(3, "Carlos", 3000.00));

        //Collections.reverse(list4);
        //Collections.shuffle(list4);
        //System.out.println(list4);

        //Típica de Java <= 6
        /*/for(int i = 0; i < list4.size(); i++){
            System.out.println(list4.get(i));
        }*/

        //Desde Java 7+
        //For mejorado / foreach / for enhancement
        /*for(Employee employee : list4){
            System.out.println(employee);
        }*/

        //Java 8 en adelante
        list4.forEach( x -> System.out.println(x.getName()));
    }
}
