package app;

import model.Car;
import model.Toyota;
import model.Vehicle;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Program{//<T, K, V, Z, MITOCODE> {

    //T = Type | Tipo de Clase
    //K = Key | Llave
    //V = Value | Valor
    //E = Element
    //? wildcard | unknown || ? extends Object

    //upper-bounded
    //algo tiene que ser menor igual que "Car"
    public <S> S m1(List<? extends Car> list){
        return null;
    }

    //lower-bounded
    //algo tiene que ser mayor igual que "Car"
    public void m2(List<? super Car> list){

    }

    public void m3(List<? extends Object> list){

    }

    public static void main(String[] args) {
        Program app = new Program();
        List<Toyota> list = new ArrayList<>();

        //app.m2(list);

        //List<? extends Car> list2 = new ArrayList<>();
        //list.add(new Car()); //safe-type
    }
}
