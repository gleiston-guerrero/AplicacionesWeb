package model;

public class Car extends Vehicle {
}
