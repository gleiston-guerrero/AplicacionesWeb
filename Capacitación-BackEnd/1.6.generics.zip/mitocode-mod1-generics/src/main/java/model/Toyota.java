package model;

public class Toyota extends Car {
}
