package model;

public class Vehicle {
}
