package app;

import model.Product;

public class Program {

    public static void main(String[] args) {
        Product p1 = new Product(1, "TV");

        System.out.println(p1);

    }
}
