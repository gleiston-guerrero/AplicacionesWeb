package function;

import model.Employee;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

//R apply(T t);
public class FunctionApp {

    private void m1(){
        Function<String, Boolean> fx = x -> x.length() > 4;

        boolean result = fx.apply("abc");

        System.out.println(result);
    }

    private void m2AndThen(){
        Function<String, Integer> fx1 = x -> x.length();
        Function<Integer, Integer> fx2 = x -> x + 10;

        int result = fx1.andThen(fx2).apply("mitocode");
        System.out.println(result);
    }

    private void m2AndThenV2() {
        Function<Integer, Integer> fx1 = x -> x * 2;
        Function<Integer, Integer> fx2 = x -> x + 10;

        int rpta = fx1.andThen(fx2).apply(5);
        System.out.println(rpta);
    }

    private void m3Compose() {
        Function<Integer, Integer> fx1 = x -> x * 2;
        Function<Integer, Integer> fx2 = x -> x + 10;

        Integer rpta = fx1.compose(fx2).apply(5);

        System.out.println(rpta);
    }

    private void m4Identity(){
        Function<Integer, Integer> fx1 = Function.identity();

        int result = fx1.apply(5);

        System.out.println(result);
    }

    private void m5Identity(){
        List<Employee> list = new ArrayList<>();
        list.add(new Employee(1, "mito1", "teacher", LocalDate.now(), 999.99, "TI"));
        list.add(new Employee(2, "mito2", "developer", LocalDate.now(), 599.99, "TI"));
        list.add(new Employee(3, "mito3", "qa", LocalDate.now(), 499.99, "QA"));

        Map<Integer, Employee> map = list.stream().collect(Collectors.toMap(Employee::getIdEmployee, Function.identity()));

        /*Map<Integer, String> map = new HashMap<>();
        for(Employee e: list){
            map.put(e.getIdEmployee(), e.getName());
        }*/

        System.out.println(map);
    }

    private void m6Identity(){
        Function<Integer, Integer> f1 = Function.identity();
        Function<Integer, Integer> f2 = Function.identity();
        Function<Integer, Integer> f3 = Function.identity();

        Function<Integer, Integer> f4 = t -> t;
        Function<Integer, Integer> f5 = t -> t;
        Function<Integer, Integer> f6 = t -> t;

        System.out.println(f1);
        System.out.println(f2);
        System.out.println(f3);
        System.out.println("================================================");
        System.out.println(f4);
        System.out.println(f5);
        System.out.println(f6);
    }

    public static void main(String[] args) {
        FunctionApp app = new FunctionApp();
        app.m6Identity();
    }
}
