package interfaces;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

//void accept(T t);
public class ConsumerApp {

    private void m1(){
        Consumer<String> fx1 = x -> System.out.println(x);
        //fx1.accept("Hello World!");

        List<Integer> list = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
        list.forEach(e -> print(e));
    }

    private void print(int x){
        System.out.println("Print Number: " + x);
    }

    public static void main(String[] args) {
        ConsumerApp app = new ConsumerApp();
        app.m1();
    }
}
