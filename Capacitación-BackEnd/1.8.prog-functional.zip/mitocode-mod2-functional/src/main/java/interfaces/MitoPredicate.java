package interfaces;

@FunctionalInterface
public interface MitoPredicate<T> {

    boolean test(T t);
}
