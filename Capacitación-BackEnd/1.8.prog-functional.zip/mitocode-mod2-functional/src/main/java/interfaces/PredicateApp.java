package interfaces;

import model.Product;

import java.util.function.Predicate;

//boolean test(T t);
public class PredicateApp {

    private void m1(){
        MitoPredicate<Integer> checkAge = x -> x >= 18;
        MitoPredicate<String> checkChars = x -> x.length() >= 8;

        boolean result = checkAge.test(5);
        boolean result2 = checkChars.test("mitocode");

        System.out.println(result);
        System.out.println(result2);
    }

    private void m2(){
        Predicate<Integer> greaterThan = x -> x > 10;
        Predicate<Integer> lowerThan = x -> x < 20;

        boolean result = greaterThan.or(lowerThan).negate().test(50);
        System.out.println(result);
    }

    private void m3(Product product, Predicate<Product> fx){
        boolean result = fx.test(product);
        System.out.println(result);
    }

    public static void main(String[] args) {
        PredicateApp app = new PredicateApp();
        //app.m2();
        //Predicate<Product> f1 = x -> x.getName().length() >= 3;
        //app.m3(new Product(1 , "TVs"), x -> x.getName().length() >= 3);
        app.m1();
    }
}
