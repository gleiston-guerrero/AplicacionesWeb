package interfaces;

import java.time.LocalDate;
import java.util.UUID;
import java.util.function.Supplier;

//T get();
public class SupplierApp {

    private void m1(){
        Supplier<LocalDate> fx = () -> LocalDate.now().minusDays(1);
        //System.out.println(fx.get());

        Supplier<String> generatePassword = () -> {
          String password = UUID.randomUUID().toString();
          password = password.replaceAll("-", "");
          return password;
        };

        String newPassword = generatePassword.get();
        System.out.println(newPassword);
    }

    public static void main(String[] args) {
        SupplierApp app = new SupplierApp();
        app.m1();
    }
}
