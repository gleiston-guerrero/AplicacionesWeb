package lambda;

import java.util.function.Predicate;

@FunctionalInterface
public interface Operation {

    int operate(int x, int y);
    //int operate2(int x, int y);

    default void print() {
        System.out.println("TEST");
    }

    static void test2(){
        System.out.println("TEST2");
    }
}
