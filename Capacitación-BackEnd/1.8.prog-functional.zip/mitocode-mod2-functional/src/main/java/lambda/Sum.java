package lambda;

public class Sum implements Operation {

    @Override
    public int operate(int x, int y) {
        return x + y;
    }
}
