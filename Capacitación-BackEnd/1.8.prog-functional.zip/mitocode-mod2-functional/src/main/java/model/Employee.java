package model;

import lombok.*;

import java.time.LocalDate;
import java.util.Objects;

//@Data
@Getter
@Setter
@ToString(onlyExplicitlyIncluded = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@AllArgsConstructor
@NoArgsConstructor
public class Employee {

    @EqualsAndHashCode.Include
    @ToString.Include
    private int idEmployee;
    @ToString.Include
    private String name;
    private String job;
    private LocalDate birthDate;
    private double salary;
    private String department;

}
