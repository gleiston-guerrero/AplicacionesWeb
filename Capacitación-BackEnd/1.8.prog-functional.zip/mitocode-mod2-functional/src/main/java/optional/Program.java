package optional;

import model.Employee;

import java.time.LocalDate;
import java.util.Optional;

public class Program {

    public static void main(String[] args) {
        //Optional<Employee> op = Optional.of(new Employee(1, "mito", "developer", LocalDate.now(), 100, "TI"));
        //Optional<Employee> op = Optional.empty();
        //Optional<Employee> op = Optional.of(null); //Ocasiona NPE
        Optional<Employee> op = Optional.ofNullable(null);

        //System.out.println(op.isPresent());
        //System.out.println(op.isEmpty());
        //System.out.println(op.get());
        //op.ifPresent( obj -> System.out.println(obj.getName()));
        System.out.println(op.orElse(new Employee()));
        //System.out.println(op.orElseGet(Employee::new)); //() -> new Employee()
        //System.out.println(op.orElseThrow( () -> new RuntimeException( "Oops!" ) ) );
    }
}
