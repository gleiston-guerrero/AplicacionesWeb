package stream;

import model.Employee;

import java.time.LocalDate;
import java.time.Period;
import java.util.*;
import java.util.function.Predicate;
import static java.util.stream.Collectors.groupingBy;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AppStream {

    private void m1getDevs(List<Employee> list, String searchText) {
        Predicate<Employee> fx = e -> e.getJob().toLowerCase().contains(searchText.toLowerCase());

        List<Employee> newList =  list.stream()
                .filter(fx)
                .toList();
                //.forEach(e -> System.out.println(e));

        newList.forEach(System.out::println);
    }

    private void m2getInverse(List<Employee> list){
        list.stream()
                .sorted(Comparator.comparing(Employee::getIdEmployee).reversed())
                .forEach(System.out::println);
    }

    private void m3getAdults(List<Employee> list){
        Predicate<Employee> isAdult = e -> Period.between(e.getBirthDate(), LocalDate.now()).getYears() >= 18;
        //Predicate<Employee> isNotAdult = e -> Period.between(e.getBirthDate(), LocalDate.now()).getYears() >= 18;

        list.stream()
                .filter(isAdult) //.negate()
                .forEach(System.out::println);
    }

    private void m4getOldestAdult(List<Employee> list){
        list.stream()
                .sorted(Comparator.comparing(Employee::getBirthDate))
                .limit(1)
                .forEach(System.out::println);
    }

    private void m5getMaxMinSalary(List<Employee> list){
       double max = list.stream()
                .mapToDouble(Employee::getSalary)
                .max()
                .orElse(0);

        double min = list.stream()
                .mapToDouble(Employee::getSalary)
                .min()
                .orElse(0);

        Employee maxEmp = list.stream()
                        .max(Comparator.comparing(Employee::getSalary))
                        .orElse(new Employee());

        System.out.println("Max: " + max);
        System.out.println("Min: " + min);
        System.out.println("Max Emp: " + maxEmp);
    }

    private void m6getAverage(List<Employee> list){
        double avg = list.stream()
                .mapToDouble(Employee::getSalary)
                .average()
                .orElse(0);

        System.out.println("Avg: " + avg);
    }

    private void m7getSummary(List<Employee> list){
        DoubleSummaryStatistics stats = list.stream()
                .mapToDouble(Employee::getSalary)
                .summaryStatistics();

        System.out.println(stats);
        System.out.println("Max Salary: " + stats.getMax());
        System.out.println("Min Salary: " + stats.getMin());
        System.out.println("Sum Salary: " + stats.getSum());
        System.out.println("Average Salary: " + stats.getAverage());
        System.out.println("Count: " + stats.getCount());
    }

    private void m8getDistinct(List<Employee> list){
        list.stream()
                .distinct()
                .forEach(System.out::println);
    }

    private void m9getCount(List<Employee> list){
        long count1 = list.stream()
                //.filter()
                .count();
        int count2 = list.size();

        System.out.println(count1);
        System.out.println(count2);
    }

    private void m10skipLimit(List<Employee> list){
        int pageNumber = 0;
        int pageSize = 5;

        list.stream()
                .skip(pageNumber * pageSize)
                .limit(pageSize)
                .forEach(System.out::println);
    }

    private void m11getAnyYounger(List<Employee> list){
        boolean result = list.stream()
                .anyMatch(e -> Period.between(e.getBirthDate(), LocalDate.now()).getYears() < 18);

        System.out.println("Is any younger in this data: " + result);
    }

    private void m12map(List<Employee> list){
        Stream<Employee> st = list.stream();
        st.map(e -> {
                    e.setSalary(e.getSalary() * 1.15);
                    return e.getSalary();
                })
                .forEach(System.out::println);
    }

    private void m13flatMap(List<Employee> list){
        list.stream()
                .flatMap(e -> {
                    e.setSalary(e.getSalary() * 1.15);
                    return Stream.of(e.getSalary(), e.getName(), e.getDepartment());
                })
                .forEach(System.out::println);
    }

    private void m14GroupBy(List<Employee> list){
        Map<String, List<Employee>> byDepartment = list.stream()
                .collect(groupingBy(Employee::getDepartment));

        Map<String, Map<String, List<Employee>>> byDepartmentAndJob = list.stream()
                .collect(groupingBy(Employee::getDepartment, groupingBy(Employee::getJob)));

        //System.out.println(byDepartment);
        System.out.println(byDepartmentAndJob);
    }

    private void m15Order(){
        Stream<String> st1 = Stream.of("z", "a", "x", "e", "t");

        st1.sorted(Comparator.reverseOrder())
                .forEach(System.out::println);
    }

    public static void main(String[] args) {
        AppStream app = new AppStream();

        Employee e1 = new Employee(1, "Mito1", "Developer", LocalDate.of(1991, 1, 1), 1000.00, "TI");
        Employee e2 = new Employee(2, "Mito2", "QA", LocalDate.of(1993, 2, 1), 2000.00, "TI");
        Employee e3 = new Employee(3, "Mito3", "Architect", LocalDate.of(1995, 3, 1), 3000.00, "TI");
        Employee e4 = new Employee(4, "Mito4", "Cloud Engineer", LocalDate.of(1987, 4, 1), 4000.00, "TI");
        Employee e5 = new Employee(5, "Mito5", "Cobol Engineer", LocalDate.of(1956, 1, 1), 5000.00, "TI");
        Employee e6 = new Employee(6, "Mito6", "Scrum Master", LocalDate.of(2002, 11, 1), 4500.00, "TI");
        Employee e7 = new Employee(7, "Mito7", "Leader Project", LocalDate.of(1998, 12, 1), 10000.00, "TI");
        Employee e8 = new Employee(8, "Mito8", "Senior Developer", LocalDate.of(1996, 7, 1), 7000.00, "TI");
        Employee e9 = new Employee(9, "Mito9", "Junior Developer", LocalDate.of(2008, 8, 1), 500.00, "TI");
        Employee e10 = new Employee(10, "Mito10", "Mobile Developer", LocalDate.of(1975, 9, 1), 3000.00, "TI");
        Employee e11 = new Employee(11, "Mito11", "Salesman", LocalDate.of(1993, 9, 1), 2000.00, "Comercial");
        Employee e12 = new Employee(11, "Mito12", "Salesmanx", LocalDate.of(1993, 9, 1), 1500.00, "Comercial");

        List<Employee> list = Arrays.asList(e1, e2, e3, e4, e5, e6, e7, e8, e9, e10, e11, e12);

        //app.m1getDevs(list, "developer");
        app.m15Order();
    }
}
