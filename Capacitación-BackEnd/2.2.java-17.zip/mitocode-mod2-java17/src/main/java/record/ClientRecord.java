package record;

import java.time.LocalDate;

public record ClientRecord(
        int id,
        String name,
        LocalDate birthDate,
        boolean status
) implements Repository { //extends no es permitido

    public static String DEFAULT_NAME = "Duke";

    public ClientRecord(LocalDate birthDate){
        this(0 , DEFAULT_NAME, birthDate, false);
    }

    public ClientRecord(String name){
        this(0, name, LocalDate.now(), true);
    }

    public String toUpperCaseName(){
        return name.toUpperCase();
    }

    public static String toUpperCaseStatic(){
        return "DUKE";
    }

    @Override
    public void sayHello() {
        System.out.println("Hello!");
    }
}
