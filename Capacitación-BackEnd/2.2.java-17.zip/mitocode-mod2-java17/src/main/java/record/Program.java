package record;

import java.time.LocalDate;

public class Program {

    public static void main(String[] args) {
        Client client = new Client(1, "mito", LocalDate.now(), true);
        ClientRecord cr = new ClientRecord(1, "mito", LocalDate.now(), true);
        ClientRecord cr2 = new ClientRecord(LocalDate.now());

        String name = ClientRecord.DEFAULT_NAME;
        //System.out.println(name);
        //System.out.println(client);
        //System.out.println(cr.name());
        System.out.println(cr2);
    }
}
