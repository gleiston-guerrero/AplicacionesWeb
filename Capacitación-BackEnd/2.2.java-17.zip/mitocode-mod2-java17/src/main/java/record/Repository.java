package record;

public interface Repository {

    void sayHello();
}
