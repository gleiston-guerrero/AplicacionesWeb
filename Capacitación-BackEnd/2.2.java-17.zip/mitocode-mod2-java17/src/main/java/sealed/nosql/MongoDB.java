package sealed.nosql;

import sealed.sql.SQL;

public class MongoDB { //extends SQL {

    /*@Override
    public void connect() {

    }

    @Override
    public void disconnect() {

    }*/
}
