package sealed.sql;

public non-sealed class MySQL extends SQL{

    @Override
    public void connect() {

    }

    @Override
    public void disconnect() {

    }
}
