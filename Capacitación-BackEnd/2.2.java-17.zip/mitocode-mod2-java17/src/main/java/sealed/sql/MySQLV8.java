package sealed.sql;

public class MySQLV8 extends MySQL{
}
