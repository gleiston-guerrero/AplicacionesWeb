package sealed.sql;

public final class SQLServer extends SQL {

    @Override
    public void connect() {

    }

    @Override
    public void disconnect() {

    }
}
