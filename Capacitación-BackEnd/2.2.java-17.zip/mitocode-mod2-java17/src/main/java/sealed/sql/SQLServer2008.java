package sealed.sql;

public class SQLServer2008 {// extends SQLServer{
}
