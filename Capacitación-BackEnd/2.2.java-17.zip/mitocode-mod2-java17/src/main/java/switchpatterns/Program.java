package switchpatterns;

public class Program {

    private void m1Basic(String param){
        switch (param) {
            case "A":
                System.out.println("Case A");
                break;
            case "B":
                System.out.println("Case B");
                break;
            default:
                System.out.println("Default Case");
        }
    }

    private void m2Arrow(String param){
        switch (param) {
            case "A" -> System.out.println("Case A");
            case "B" -> System.out.println("Case B");
            default -> System.out.println("Default Case");
        }
    }

    private String m3Yield(String param){
        return switch (param) {
            case "A" : yield "Case A";
            case "B" : yield "Case B";
            default: yield "Default Case";
        };
    }

    private String m4ArrowReturn(String param){
        return switch (param){
            case "A" -> "Case A";
            case "B" -> {
                //
                //
                yield "Case B";
            }
            default -> "Default Case";
        };
    }

    private void m5MultipleCase(String param){
        switch (param) {
            case "A", "B" -> System.out.println("Case A & B");
            case "C", "D" -> System.out.println("Case C & D");
            case "E", "F", "G" -> System.out.println("Case E, F & G");
            default ->  System.out.println("Default Case");
        }
    }

    public static void main(String[] args) {
        Program app = new Program();
        //app.m2Arrow("A");
        //String result = app.m3Yield("A");
        app.m5MultipleCase("E");
    }
}
