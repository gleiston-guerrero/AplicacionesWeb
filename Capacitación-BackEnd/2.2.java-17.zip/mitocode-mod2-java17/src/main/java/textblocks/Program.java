package textblocks;

public class Program {

    private void m1Simple(){
        String text = """
                    Este es un bloque de texto
                que no requiere
                un operador +
                """;

        System.out.println(text);
    }

    private void m2Indentation(){
        String page = """
                <html>
                    <body>
                        <span>example text</span>
                    </body>
                </html>""";

        String json = """
                {
                    "name": "mito",
                    "age": 34,
                    "status": true
                }
                """;

        System.out.println(json);
    }

    private void m3Scape(){
        String text = """
                Hola este es el curso de "Java 21 backend\" \" \"
                """;

        System.out.println(text);
    }

    private void m4TextWithVariables(String name, int age, boolean status){
        String json = """
                {
                    "name": $name,
                    "age": $age,
                    "status": #status
                }
                """.replace("$name", name)
                .replace("$age", String.valueOf(age))
                .replace("#status", String.valueOf(status));

        System.out.println(json);
    }

    public static void main(String[] args) {
        Program app = new Program();
        app.m4TextWithVariables("mito", 34, true);
    }
}
