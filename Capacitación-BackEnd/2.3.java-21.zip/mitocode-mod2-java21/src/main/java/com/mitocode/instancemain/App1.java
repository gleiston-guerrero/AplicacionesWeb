package com.mitocode.instancemain;

public class App1 {

    /*public static void main(String[] args) {
        System.out.println("Java 21");
    }*/

    void main(){
        System.out.println("Java 21");
    }

    /*static void main(){
        System.out.println("Java 21");
    }*/

    /*void main(String[] args){
        System.out.println("Java 21");
    }*/
}
