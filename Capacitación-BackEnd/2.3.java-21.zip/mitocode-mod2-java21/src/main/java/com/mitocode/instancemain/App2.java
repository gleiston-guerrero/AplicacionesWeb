import com.mitocode.model.Product;

int number = 33;
Product p = new Product(1, "TV", 99, true);

void main(){
    System.out.println("Java 21");
    int result = sum(5,5);
    System.out.println(result);
    System.out.println(number);
    System.out.println(p.getName());
}

int sum(int x, int y){
    return x + y;
}