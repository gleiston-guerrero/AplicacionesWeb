package com.mitocode.model;

public record ProductRecord(
        int id,
        String name,
        double price,
        boolean status
) {
}
