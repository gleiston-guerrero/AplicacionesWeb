package com.mitocode.recordpattern;

import com.mitocode.model.Product;
import com.mitocode.model.ProductRecord;

import java.util.ArrayList;
import java.util.List;

public class RecordApp {

    private void m1(Object param){
        if(param instanceof ProductRecord pr){
            System.out.println(pr);
            System.out.println(pr.name());
            System.out.println(pr.price());
        }
    }

    private void m2(Object param){
        if(param instanceof ProductRecord(int x, var name, var price, boolean st)){
            System.out.println(x);
            System.out.println(name);
        }
    }

    //Desde Java 19, revisado en Java 20 y removido en Java 21
    private void m3(Object param){
        List<ProductRecord> list = new ArrayList<>();
        list.add(new ProductRecord(1, "TV1", 999.99, true));
        list.add(new ProductRecord(2, "TV2", 899.99, true));
        list.add(new ProductRecord(3, "TV3", 799.99, true));

        /*for(ProductRecord(int a, String b, double c, boolean d) : list){
            System.out.println(a);
            System.out.println(b);
        }

        for(ProductRecord(var a, var b, var c, var d): list){
            System.out.println(a);
            System.out.println(b);
        }*/
    }

    public static void main(String[] args) {
        RecordApp app = new RecordApp();
        app.m2(new ProductRecord(1, "TV", 99.99, true));
    }
}
