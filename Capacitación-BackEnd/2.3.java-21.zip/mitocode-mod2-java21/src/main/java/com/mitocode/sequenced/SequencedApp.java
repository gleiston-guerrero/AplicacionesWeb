package com.mitocode.sequenced;

import com.mitocode.model.Product;

import java.util.*;

public class SequencedApp {

    public static void main(String[] args) {
        List<Product> products = new ArrayList<>();
        products.add(new Product(1, "TV1", 299.99, true));
        products.add(new Product(2, "TV2", 399.99, true));
        products.add(new Product(3, "TV3", 499.99, true));

        products.addFirst(new Product(0, "TV0", 199.99, true));
        products.addLast(new Product(4, "TV4", 599.99, true));

        Product firstProduct = products.getFirst();
        Product lastProduct = products.getLast();

        //System.out.println(firstProduct);
        //System.out.println(lastProduct);

        SequencedMap<Integer, Product> map = new LinkedHashMap<>();
        map.put(1, new Product(1, "TV1", 299.99, true));
        map.put(2, new Product(2, "TV2", 399.99, true));
        map.put(3, new Product(3, "TV3", 499.99, true));

        map.pollFirstEntry();
        map.pollLastEntry();

        Map.Entry<Integer, Product> firstEntry = map.firstEntry();
        Map.Entry<Integer, Product> lastEntry = map.lastEntry();

        System.out.println(firstEntry);
        System.out.println(lastEntry);
    }
}
