package com.mitocode.stringtemplate;

public class StringTemplateApp {

    public static void main(String[] args) {
        String user = "mitocode";

        String text = STR."Hola \{user}";

        String supperMessage = STR."""
                Hola usuario \{user}
                """;

        System.out.println(supperMessage);
        System.out.println(text);
    }
}
