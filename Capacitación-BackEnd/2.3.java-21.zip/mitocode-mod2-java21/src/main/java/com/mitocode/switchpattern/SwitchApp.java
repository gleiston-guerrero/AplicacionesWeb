package com.mitocode.switchpattern;

import com.mitocode.model.Product;
import com.mitocode.model.ProductRecord;

public class SwitchApp {

    private String m1(Object param){
        /* if(param instanceof String){

        }else if(param instanceof Integer){

        }else if(param instanceof Product){

        }*/

        return switch (param){
            case String a -> "Case String";
            case Integer b when (b > 10 && b < 20)  -> "Case Integer";
            case Product p when test(p) -> "Case Product";
            case null -> "Case Null";
            case ProductRecord r when r.id() > 50 -> "Case ProductRecord";
            default -> "Case Default";
        };
    }

    private boolean test(Product p){
        return false;
    }

    public static void main(String[] args) {
        SwitchApp app = new SwitchApp();
        String result = app.m1(new ProductRecord(55, "TV1", 999.99, true));
        System.out.println(result);
    }
}
