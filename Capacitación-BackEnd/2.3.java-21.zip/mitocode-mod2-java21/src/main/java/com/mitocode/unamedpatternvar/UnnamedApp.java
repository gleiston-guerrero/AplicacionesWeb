package com.mitocode.unamedpatternvar;

import com.mitocode.model.ProductRecord;

public class UnnamedApp {

    private void m1(Object param){
        if(param instanceof ProductRecord(int id, String name, double _, boolean _)){
            System.out.println(id);
            System.out.println(name);
            //System.out.println(_); //NO SE PUEDE
        }

        try{

        }catch (Exception _){
            System.out.println("FALLO");
        }

        int _ = calculate();
    }

    private int calculate(){
        //
         //
         //
         //
        return 0;
    }
}
