package com.mitocode.vthreads;

import java.time.Duration;
import java.time.Instant;
import java.util.Random;

public class VThread {

    public void m1Basic() throws InterruptedException {
        Runnable r = () -> {
            for(int i = 0; i < 10; i++) {
                System.out.println("Index: " + i);
            }
        };

        Thread vthread = Thread.ofVirtual().start(r);
        vthread.join();
    }

    public void m2TestPerformance(boolean vThreads) {
        System.out.println(STR."vThreads: \{vThreads}");

        Instant start = Instant.now();

        Random random = new Random();
        Runnable runnable = () -> {
            double i = random.nextDouble(1000) % random.nextDouble(1000);
        };

        for(int i=0; i< 50_000; i++){
            if(vThreads){
                Thread.startVirtualThread(runnable);
            }else{
                Thread t = new Thread(runnable);
                t.start();
            }
        }

        Instant end = Instant.now();

        long time = Duration.between(start, end).toMillis();
        System.out.println(STR."Time : \{time}");
    }

    public static void main(String[] args) throws InterruptedException {
        VThread vthread = new VThread();
        vthread.m2TestPerformance(true);
    }
}
