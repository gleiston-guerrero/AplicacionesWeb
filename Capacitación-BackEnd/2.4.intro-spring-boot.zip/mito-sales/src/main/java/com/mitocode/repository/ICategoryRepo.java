package com.mitocode.repository;

import com.mitocode.model.Category;

public interface ICategoryRepo {

    Category save(Category category);
}
