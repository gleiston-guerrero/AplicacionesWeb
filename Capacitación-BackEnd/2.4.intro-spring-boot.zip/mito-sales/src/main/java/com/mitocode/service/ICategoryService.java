package com.mitocode.service;

import com.mitocode.model.Category;

public interface ICategoryService {

    Category validAndSave(Category category);
}
