var entrada=document.getElementById('tarea');
var lista=document.getElementById('listaTareas');
var mensaje=document.getElementById('mensaje');

function Agregar(){
    const texto = entrada.value.trim();

    if (texto === "") {
        mensaje.textContent = "❌ Debes escribir una tarea.";
        mensaje.style.color = "red";
        return;
    }

    mensaje.textContent = "";

    // Crear un nuevo <li>
    const li = document.createElement("li");
    li.textContent = texto;

    // Crear botón de eliminar
    const btnElimina = document.createElement("button");
    btnElimina.textContent = "X";
    btnElimina.style.marginLeft = "10px";
    btnElimina.style.background = "crimson";

    // Evento para eliminar tarea individual
    btnElimina.addEventListener("click", () => {
        lista.removeChild(li);
    });

    li.appendChild(btnElimina);
    lista.appendChild(li);

    entrada.value = "";
}


function Resaltar(){
    let items=document.querySelectorAll('#listaTareas li');
    items.forEach(li=>li.classList.toggle("resaltado"));
}
function Limpiar(){
    lista.innerHTML="";
    mensaje.textContent="✔ Todas las tareas eliminadas";
    mensaje.style.color="green";
}