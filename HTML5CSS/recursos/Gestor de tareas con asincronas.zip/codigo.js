// Capturar elementos del DOM
const entrada = document.getElementById("tarea");
const btnAgregar = document.querySelector('#btnAgregar');
const lista = document.getElementById("listaTareas");
const btnResaltar = document.getElementById("btnResaltar");
const btnLimpiar = document.getElementById("btnLimpiar");
const mensaje = document.getElementById("mensaje");

const cargador = document.getElementById("cargador");
const API_URL = "http://localhost:3000/tareas";



// -------------------- FUNCIONES DOM -------------------------

function mostrarCargador() {
    cargador.classList.remove("oculto");
}

function ocultarCargador() {
    cargador.classList.add("oculto");
}

// -------------------- Obtener tareas (GET) --------------------
async function cargarTareas() {
    mostrarCargador();
    try {
        const resp = await fetch(API_URL);
        const datos = await resp.json();
        renderizarLista(datos);
    } catch (error) {
        mensaje.textContent = "Error al cargar tareas.";
        mensaje.style.color = "red";
    } finally {
        ocultarCargador();
    }
}


// -------------------- Renderizar en el DOM --------------------
function renderizarLista(tareas) {
    lista.innerHTML = "";

    tareas.forEach(t => {
        const li = document.createElement("li");
        li.textContent = t.texto;

        const btnElimina = document.createElement("button");
        btnElimina.textContent = "X";
        btnElimina.style.marginLeft = "10px";
        btnElimina.style.background = "crimson";

        // Evento eliminar (DELETE)
        btnElimina.onclick = () => eliminarTarea(t.id);

        li.appendChild(btnElimina);
        lista.appendChild(li);
    });
}


// -------------------- Agregar tarea (POST) --------------------
btnAgregar.addEventListener("click", async () => {
    const texto = entrada.value.trim();

    if (texto.length < 3) {
        mensaje.textContent = "❌ La tarea es demasiado corta.";
        mensaje.style.color = "red";
        return;
    }

    mostrarCargador();

    try {
        await fetch(API_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ texto })
        });

        mensaje.textContent = "✔ Tarea agregada";
        mensaje.style.color = "green";

        cargarTareas();

    } catch (error) {
        mensaje.textContent = "❌ Error al guardar tarea.";
        mensaje.style.color = "red";

    } finally {
        ocultarCargador();
        entrada.value = "";
    }
});


// -------------------- Eliminar tarea (DELETE) --------------------
async function eliminarTarea(id) {
    mostrarCargador();
    try {
        await fetch(`${API_URL}/${id}`, { method: "DELETE" });

        mensaje.textContent = "✔ Tarea eliminada";
        mensaje.style.color = "green";

        cargarTareas();

    } catch (error) {
        mensaje.textContent = "❌ Error al eliminar tarea.";
        mensaje.style.color = "red";
    } finally {
        ocultarCargador();
    }
}


// -------------------- Resaltar --------------------
btnResaltar.addEventListener("click", () => {
    let items = document.querySelectorAll("#listaTareas li");
    items.forEach(li => li.classList.toggle("resaltado"));
});


// -------------------- Eliminar todas (DELETE en cadena) --------------------
btnLimpiar.addEventListener("click", async () => {
    mostrarCargador();

    try {
        const resp = await fetch(API_URL);
        const tareas = await resp.json();

        // Elimina una por una
        for (let t of tareas) {
            await fetch(`${API_URL}/${t.id}`, { method: "DELETE" });
        }

        mensaje.textContent = "✔ Todas eliminadas";
        mensaje.style.color = "green";

        cargarTareas();

    } catch (error) {
        mensaje.textContent = "❌ Error al eliminar todas.";
        mensaje.style.color = "red";
    } finally {
        ocultarCargador();
    }
});


// -------------------- Cargar inicial --------------------
cargarTareas();