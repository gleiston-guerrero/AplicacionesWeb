// Capturar elementos del DOM
const entrada = document.getElementById("tarea");
const btnAgregar = document.querySelector('#btnAgregar');
const lista = document.getElementById("listaTareas");
const btnResaltar = document.getElementById("btnResaltar");
const btnLimpiar = document.getElementById("btnLimpiar");
const mensaje = document.getElementById("mensaje");


// Evento: Agregar tarea

btnAgregar.addEventListener("click", () => {
    const texto = entrada.value.trim();
    

    if (texto === "") {
        mensaje.textContent = "❌ Debes escribir una tarea.";
        mensaje.style.color = "red";
        return;
    }

    mensaje.textContent = "";

    // Crear un nuevo <li>
    const li = document.createElement("li");
    li.textContent = texto;

    // Crear botón de eliminar
    const btnEliminar = document.createElement("button");
    btnEliminar.textContent = "X";
    btnEliminar.style.marginLeft = "10px";
    btnEliminar.style.background = "crimson";

    // Evento para eliminar tarea individual
    btnEliminar.addEventListener("click", () => {
        lista.removeChild(li);
    });

    li.appendChild(btnEliminar);
    lista.appendChild(li);

    input.value = "";
});


// Resaltar con classList
btnResaltar.addEventListener("click", () => {
    let items = document.querySelectorAll("#listaTareas li");
    items.forEach(li => li.classList.toggle("resaltado"));
});

// Eliminar todas las tareas
btnLimpiar.addEventListener("click", () => {
    lista.innerHTML = "";
    mensaje.textContent = "✔ Todas las tareas eliminadas.";
    mensaje.style.color = "green";
});