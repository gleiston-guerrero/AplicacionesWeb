class Persona {
    #nombre
    #edad
    constructor(nombre, edad){
        this.#nombre=nombre;
        this.#edad=edad;
    }
    obtenerTipo() {
        return "persona";
    }
    getNombre(){
        return this.#nombre;
    }
     getEdad(){
        return this.#edad;
    }
}

class Estudiante extends Persona{
    #matricula
    constructor(nombre, edad, matricula){
        super(nombre,edad);
        this.#matricula=matricula;
    }
     obtenerTipo() {
        return "estudiante";
    }
    getMatricula(){
        return this.#matricula;
    }
}

const tipo=document.getElementById("tipo");
const campoMatricula=document.getElementById("campoMatricula");
const lista=document.getElementById("lista");
const errores=document.getElementById("errores");

function SeleccionarTipo(){
    if (tipo.value==="estudiante"){
        campoMatricula.classList.remove("oculto");
    }
    else {
        campoMatricula.classList.add("oculto");
    }

}

function ValidarFormulario(nombre, edad, tipoUsuario, matricula) {
    let mensajes=[];
    
    if (nombre.trim().length<2){
        mensajes.push("El nombre debe tener al menos 2 caracteres");
    }

    if (edad==="" || edad<1 || edad >120){
        mensajes.push("La edad debe estar entre 1 y 120");
    }
    if (tipoUsuario==="estudiante"){
        if (matricula.trim()=="") {
            mensajes.push("La matrícula es obligatoria para estudiantes");
        }else if (!/^[a-zA-Z0-9]{3,10}$/.test(matricula))  {
            mensajes.push("La matrícula debe ser alfanumérica de 3 a 10 caracteres");
        }
    }

    return mensajes;
}

function Agregar(){
    const nombre=document.getElementById("nombre").value;
    const edad=document.getElementById("edad").value;
    let matricula=document.getElementById("matricula").value;
   


    const mensajesError=ValidarFormulario(nombre, edad, tipo.value, matricula);

    if (mensajesError.length>0) {
        errores.textContent=mensajesError.join("\n");
        return;
    }

    errores.textContent="";

    let objeto;
    console.log(tipo.value);
    if (tipo.value==="persona"){
        objeto=new Persona(nombre, edad);
        matricula="-";
    }
    else {
        objeto=new Estudiante(nombre, edad, matricula);
    }
    agregarFila(objeto,matricula);

}



function agregarFila(obj,matricula){

    const fila=document.createElement("tr");

    fila.innerHTML=`
                   <td>${obj.obtenerTipo()}</td>
                   <td>${obj.getNombre()}</td>
                   <td>${obj.getEdad()}</td>
                   <td>${matricula}</td>
                   }
    `;
    lista.appendChild(fila);
}