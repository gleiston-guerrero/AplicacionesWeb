function iniciarPromesa() {
      document.getElementById("mensaje").textContent = "Cargando datos...";
      // Simulamos una promesa que se resuelve después de 3 segundos
      let promesa = new Promise((resolve, reject) => {
        setTimeout(() => {
          resolve("✅ Datos cargados correctamente.");
        }, 6000);
      });
      // Manejo del resultado de la promesa
      promesa.then(resultado => {
        document.getElementById("mensaje").textContent = resultado;
      });
    }

    