// SIMULACIÓN DE UNA BASE DE DATOS REMOTA =======================

// Simula una petición al servidor para obtener tareas
function obtenerTareas() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(tareas); // retorna el arreglo actual
        }, 800);
    });
}

// Simula agregar una tarea al "servidor"
function guardarTarea(texto) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (texto.length < 3) {
                reject("La tarea es demasiado corta.");
            } else {
                tareas.push(texto);
                resolve("Tarea guardada correctamente.");
            }
        }, 1000);
    });
}

// Simula la eliminación de una tarea
function eliminarTareaAsync(texto) {
    return new Promise((resolve) => {
        setTimeout(() => {
            tareas = tareas.filter(t => t !== texto);
            resolve("Tarea eliminada.");
        }, 700);
    });
}

// ================================================================

// Lista de tareas (simulando BD)
let tareas = [];

// Elementos del DOM
const entrada = document.getElementById("tarea");
const btnAgregar = document.getElementById("btnAgregar");
const lista = document.getElementById("listaTareas");
const btnResaltar = document.getElementById("btnResaltar");
const btnLimpiar = document.getElementById("btnLimpiar");
const mensaje = document.getElementById("mensaje");
const cargador = document.getElementById("cargador");


// -------------------- FUNCIONES DOM -------------------------

function mostrarCargador() {
    cargador.classList.remove("oculto");
}

function ocultarCargador() {
    cargador.classList.add("oculto");
}

function renderizarLista() {
    lista.innerHTML = "";

    tareas.forEach(texto => {
        const li = document.createElement("li");
        li.textContent = texto;

        const btnElimina = document.createElement("button");
        btnElimina.textContent = "X";
        btnElimina.style.marginLeft = "10px";
        btnElimina.style.background = "crimson";

        // Eventos asincrónicos con Promesa
        btnElimina.onclick = async () => {
            mostrarCargador();

            const msg = await eliminarTareaAsync(texto);

            mensaje.textContent = msg;
            mensaje.style.color = "blue";
            ocultarCargador();
            renderizarLista();
        };

        li.appendChild(btnElimina);
        lista.appendChild(li);
    });
}


// -------------------- EVENTO AGREGAR -------------------------

btnAgregar.addEventListener("click", async () => {
    const texto = entrada.value.trim();

    if (texto === "") {
        mensaje.textContent = "❌ Debes escribir una tarea.";
        mensaje.style.color = "red";
        return;
    }

    mostrarCargador();

    try {
        const resp = await guardarTarea(texto);
        mensaje.textContent = "✔ " + resp;
        mensaje.style.color = "green";
    } catch (error) {
        mensaje.textContent = "❌ " + error;
        mensaje.style.color = "red";
    } finally {
        ocultarCargador();
        renderizarLista();
    }

    entrada.value = "";
});


// -------------------- RESALTAR -------------------------

btnResaltar.addEventListener("click", () => {
    let items = document.querySelectorAll("#listaTareas li");
    items.forEach(li => li.classList.toggle("resaltado"));
});

// -------------------- ELIMINAR TODAS -------------------------

btnLimpiar.addEventListener("click", async () => {
    mostrarCargador();

    // Simular eliminación completa con Promesa
    await new Promise(resolve => setTimeout(resolve, 800));

    tareas = [];
    renderizarLista();

    mensaje.textContent = "✔ Todas las tareas eliminadas.";
    mensaje.style.color = "green";

    ocultarCargador();
});


// -------------------- CARGAR TAREAS INICIALES (PROMESA) -------------------------

async function iniciarApp() {
    mostrarCargador();
    tareas = await obtenerTareas();
    ocultarCargador();
    renderizarLista();
}

iniciarApp();