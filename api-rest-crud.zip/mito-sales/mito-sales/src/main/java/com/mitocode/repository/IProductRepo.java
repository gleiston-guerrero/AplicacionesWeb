package com.mitocode.repository;

import com.mitocode.model.Product;

public interface IProductRepo extends IGenericRepo<Product, Integer>{
}
