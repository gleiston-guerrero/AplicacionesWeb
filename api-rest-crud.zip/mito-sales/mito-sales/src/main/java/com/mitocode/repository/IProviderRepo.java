package com.mitocode.repository;

import com.mitocode.model.Provider;

public interface IProviderRepo extends IGenericRepo<Provider, Integer> {

}
