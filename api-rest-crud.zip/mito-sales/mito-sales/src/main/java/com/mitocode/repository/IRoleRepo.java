package com.mitocode.repository;

import com.mitocode.model.Role;

public interface IRoleRepo extends IGenericRepo<Role, Integer> {

}
