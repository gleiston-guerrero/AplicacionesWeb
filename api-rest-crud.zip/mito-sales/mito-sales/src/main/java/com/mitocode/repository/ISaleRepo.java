package com.mitocode.repository;

import com.mitocode.model.Sale;

public interface ISaleRepo extends IGenericRepo<Sale, Integer> {

}
