package com.mitocode.service;

import com.mitocode.model.Product;

public interface IProductService extends ICRUD<Product, Integer>{


}
