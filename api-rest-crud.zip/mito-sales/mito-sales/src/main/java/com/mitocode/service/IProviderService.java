package com.mitocode.service;

import com.mitocode.model.Provider;

public interface IProviderService extends ICRUD<Provider, Integer>{


}
