package com.mitocode.service;

import com.mitocode.model.Role;

public interface IRoleService extends ICRUD<Role, Integer>{


}
