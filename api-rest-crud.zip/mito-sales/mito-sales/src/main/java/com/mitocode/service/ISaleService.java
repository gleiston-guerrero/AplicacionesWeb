package com.mitocode.service;

import com.mitocode.model.Sale;

public interface ISaleService extends ICRUD<Sale, Integer>{


}
