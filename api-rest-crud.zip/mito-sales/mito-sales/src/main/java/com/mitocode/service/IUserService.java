package com.mitocode.service;

import com.mitocode.model.User;

public interface IUserService extends ICRUD<User, Integer>{


}
