package org.uteq.app;

public abstract class Person {
    public abstract int calculateAge();
}
