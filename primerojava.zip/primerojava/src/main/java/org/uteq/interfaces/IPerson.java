package org.uteq.interfaces;

public interface IPerson{
    int calculateAge();
    void incrementAge(int age);
}
