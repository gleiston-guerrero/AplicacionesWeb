package org.uteq.util;

public enum Status {
    ACTIVE, INACTIVE,DELETED, UPDATED
}
