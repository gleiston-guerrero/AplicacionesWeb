package org.uteq.repository;

import org.uteq.model.Client;

public interface IClientRepo extends IGenericRepo<Client, Integer> {

}
