package org.uteq.repository;

import org.uteq.model.Product;

public interface IProductRepo extends IGenericRepo<Product, Integer>{
}
