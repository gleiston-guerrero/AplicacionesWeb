package org.uteq.repository;

import org.uteq.model.Provider;

public interface IProviderRepo extends IGenericRepo<Provider, Integer> {

}
