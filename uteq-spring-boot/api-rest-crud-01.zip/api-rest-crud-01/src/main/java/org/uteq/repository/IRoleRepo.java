package org.uteq.repository;

import org.uteq.model.Role;

public interface IRoleRepo extends IGenericRepo<Role, Integer> {

}
