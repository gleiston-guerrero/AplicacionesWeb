package org.uteq.repository;

import org.uteq.model.Sale;

public interface ISaleRepo extends IGenericRepo<Sale, Integer> {

}
