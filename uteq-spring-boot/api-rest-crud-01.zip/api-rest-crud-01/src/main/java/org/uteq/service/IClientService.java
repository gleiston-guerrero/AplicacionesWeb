package org.uteq.service;

import org.uteq.model.Client;

public interface IClientService extends ICRUD<Client, Integer>{
}
