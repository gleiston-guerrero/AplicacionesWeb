package org.uteq.service;

import org.uteq.model.Product;

public interface IProductService extends ICRUD<Product, Integer>{


}
