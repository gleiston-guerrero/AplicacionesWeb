package org.uteq.service;

import org.uteq.model.Provider;

public interface IProviderService extends ICRUD<Provider, Integer>{


}
