package org.uteq.service;

import org.uteq.model.Role;

public interface IRoleService extends ICRUD<Role, Integer>{


}
