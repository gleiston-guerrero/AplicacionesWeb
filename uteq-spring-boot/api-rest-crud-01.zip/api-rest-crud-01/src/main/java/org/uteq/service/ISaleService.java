package org.uteq.service;

import org.uteq.model.Sale;

public interface ISaleService extends ICRUD<Sale, Integer>{


}
