package org.uteq.service;

import org.uteq.model.User;

public interface IUserService extends ICRUD<User, Integer>{


}
