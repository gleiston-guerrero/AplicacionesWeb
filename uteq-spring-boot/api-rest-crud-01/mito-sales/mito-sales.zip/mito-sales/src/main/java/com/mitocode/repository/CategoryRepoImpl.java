package com.mitocode.repository;

import com.mitocode.model.Category;
import org.springframework.stereotype.Repository;

//@Repository
public class CategoryRepoImpl{ // {implements ICategoryRepo {

    /*@Override
    public Category save(Category category) {
        System.out.println("Saving Category....");
        return category;
    }*/
}
