package com.mitocode.service;

import com.mitocode.model.Client;

public interface IClientService extends ICRUD<Client, Integer>{


}
