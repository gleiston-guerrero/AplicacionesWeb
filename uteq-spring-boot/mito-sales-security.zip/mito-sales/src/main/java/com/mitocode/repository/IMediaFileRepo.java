package com.mitocode.repository;

import com.mitocode.model.MediaFile;

public interface IMediaFileRepo extends IGenericRepo<MediaFile, Integer>{
}
