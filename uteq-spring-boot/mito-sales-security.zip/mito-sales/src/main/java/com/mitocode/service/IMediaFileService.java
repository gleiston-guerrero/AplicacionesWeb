package com.mitocode.service;

import com.mitocode.model.MediaFile;

public interface IMediaFileService extends ICRUD<MediaFile, Integer>{
}
