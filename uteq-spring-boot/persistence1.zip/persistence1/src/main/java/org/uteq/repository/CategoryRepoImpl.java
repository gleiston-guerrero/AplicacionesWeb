package org.uteq.repository;

//@Repository
public class CategoryRepoImpl{ // {implements ICategoryRepo {

    /*@Override
    public Category save(Category category) {
        System.out.println("Saving Category....");
        return category;
    }*/
}
