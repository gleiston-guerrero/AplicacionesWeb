package org.uteq.repository;

import org.uteq.model.Category;

//@Repository
public interface ICategoryRepo extends IGenericRepo<Category, Integer> {

    //Category save(Category category);
}
