package org.uteq.service;

import org.uteq.model.Category;

public interface ICategoryService extends ICRUD<Category,Integer> {

    /*Category save(Category category) throws Exception;
    Category update(Integer id, Category category) throws Exception;
    List<Category> findAll() throws Exception;
    Category findById(Integer id) throws Exception;
    void delete(Integer id) throws Exception;*/
    //Category validAndSave(Category category);
}
